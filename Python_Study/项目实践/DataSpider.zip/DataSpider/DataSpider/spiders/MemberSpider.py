# encoding:utf-8
import scrapy
from DataSpider.items import MemberItem
from scrapy.http import Request, FormRequest


class MemberSpider(scrapy.Spider):

    def __init__(self):
        self.pageNum = 1
        self.allPageNum = 0
        self.name = 'member'
        self.start_urls = [
            'https://hc.lzybd.com/store/BrowseMember.aspx',
        ]

        self.cookies = {'ASP.NET_SessionId': '1lbo4k45lylme355cctgbfnf'}
        self.headers = {
            'Connection': 'keep-alive',
            'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.82 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate, br',
            'Accept-Language': 'zh-CN,zh;q=0.9',
            'Cache-Control': 'max-age=0',
            'Connection': 'keep-alive',
            'Cookie': 'ASP.NET_SessionId=1lbo4k45lylme355cctgbfnf',
            'Host': 'hc.lzybd.com',
            'Origin':'https://hc.lzybd.com',
            'Referer':'https://hc.lzybd.com/store/BrowseMember.aspx',
            'Upgrade-Insecure-Requests': '1',
            'User-Agent':'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_13_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/69.0.3497.100 Safari/537.36'
        }

    def start_requests(self):
        yield scrapy.Request(url=self.start_urls[0],headers=self.headers,meta = {'cookiejar' : 1},cookies=self.cookies,callback=self.post_page)

    def post_page(self, response):
        # 设置cookie后发送请求分页数据的post
        viewState = response.xpath('//input[@id="__VIEWSTATE"]/@value').extract_first()
        eventValidation = response.xpath('//input[@id="__EVENTVALIDATION"]/@value').extract_first()
        yield FormRequest.from_response(response,
                            meta = {'cookiejar' : response.meta['cookiejar']},
                            headers = self.headers,
                            method = 'POST',
                            formdata = {
                            '__EVENTTARGET':'',
                            '__EVENTARGUMENT':'',
                            '__MAGICAJAX_SCRIPT_FINGERPRINTS':'',
                            '__VIEWSTATE':viewState,
                            '__MAGICAJAX_HEAD_FINGERPRINTS':'4F30B16F;F25E6AF5',
                            '__VIEWSTATEENCRYPTED':'',
                            '__EVENTVALIDATION':eventValidation,
                            'Panel0_QueryFiled':'bianhao',
                            'Panel0_QueryOperator':'like',
                            'Panel0_QueryKey':'',
                            'Panel0_Period$Period':'0',
                            'sex':'on',
                            'papernumber':'on',
                            'levelname':'on',
                            'tuijian':'on',
                            'azname':'on',
                            'qishu':'on',
                            'operationdate':'on',
                            'Daction':'on',
                            'Panel0_Submit':'(unable to decode value)',
                            'Footer$MyCon':''
                            },
                            callback = self.parse,
                            dont_filter = True
                            )

    def parse(self, response):
        # print response.text
        allPageNumText = response.xpath('//span[@id="RowCount"]//text()').extract_first()[4:]
        # 总页码
        self.allPageNum = int(allPageNumText)/15
        table = response.xpath('//table[@id="Panel1_MemberList"]')
        for members in table.xpath('tr'):
            print members
            member = members.xpath('td')
            print member
            item = MemberItem()
            item['mid'] = member[0].css('td::text').extract()
            item['name'] = member[1].css('td::text').extract()
            item['size'] = member[2].css('td::text').extract()
            item['card'] = member[3].css('td::text').extract()
            item['level'] = member[4].css('td::text').extract()
            item['parent'] = member[5].css('td::text').extract()
            item['settlePersion'] = member[6].css('td::text').extract()
            item['period'] = member[7].css('td::text').extract()
            item['time'] = member[8].css('td::text').extract()
            item['status'] = member[9].css('img').xpath('@src').extract()
            yield item

        # 分页数据递归获取
        if self.pageNum <= self.allPageNum:
            self.pageNum +=1
            print '+++++++++++++++++++++++++++++++++++++++++++++++'
            print str(self.pageNum)
            viewState = response.xpath('//input[@id="__VIEWSTATE"]/@value').extract_first()
            condition = response.xpath('//input[@id="Panel1_Condition"]/@value').extract_first()
            yield FormRequest.from_response(response,
                            meta = {'cookiejar' : response.meta['cookiejar']},
                            headers = self.headers,
                            method = 'POST',
                            formdata = {
                            '__EVENTTARGET':'gpage',
                            '__EVENTARGUMENT':'',
                            '__LASTFOCUS':'',
                            '__MAGICAJAX_SCRIPT_FINGERPRINTS':'',
                            '__VIEWSTATE':viewState,
                            '__MAGICAJAX_HEAD_FINGERPRINTS':'4F30B16F;F25E6AF5',
                            '__VIEWSTATEENCRYPTED':'',
                            'Panel0_QueryFiled':'bianhao',
                            'Panel0_QueryOperator':'like',
                            'Panel0_QueryKey':'',
                            'Panel0_Period$Period':'0',
                            'sex':'on',
                            'papernumber':'on',
                            'levelname':'on',
                            'tuijian':'on',
                            'azname':'on',
                            'qishu':'on',
                            'operationdate':'on',
                            'Daction':'on',
                            'Panel1_Condition':condition,
                            'gpage': str(self.pageNum),
                            'Footer$MyCon':''
                            },
                            callback = self.parse,
                            dont_filter = True
                            )