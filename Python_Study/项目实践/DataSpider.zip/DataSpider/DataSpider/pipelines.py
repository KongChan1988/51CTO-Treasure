# encoding:utf-8
import json
import io

# 把字段存入json文件中
class DataspiderPipeline(object):
    def __init__(self):
        self.file = io.open("data.json", 'a', encoding='utf-8')

    def process_item(self, item, spider):
        line = json.dumps(dict(item), ensure_ascii=False) + "\n"
        self.file.write(line)
        return item
