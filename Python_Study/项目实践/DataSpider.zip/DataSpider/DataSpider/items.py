#encoding:utf-8
import scrapy

class MemberItem(scrapy.Item):
    mid = scrapy.Field()
    name = scrapy.Field()
    size = scrapy.Field()
    card = scrapy.Field()
    level = scrapy.Field()
    parent = scrapy.Field()
    settlePersion = scrapy.Field()
    period = scrapy.Field()
    time = scrapy.Field()
    status = scrapy.Field()
