from django.shortcuts import render,redirect,HttpResponse
from cmdb import models
import json
# Create your views here.
def business(request):
    v1 = models.Business.objects.all()
    v2 = models.Business.objects.all().values("id","caption")  #类似select id,caption from Business
    v3 = models.Business.objects.all().values_list("id","caption") #QuerySet类型 元组形式[(1,运维),(2,开发)]
    return render(request,"business.html",{"v1":v1,"v2":v2,"v3":v3})

def host(request):
    if request.method == "GET":
        v1 = models.Host.objects.filter(nid__gt=0)   # id__gt=0 取id大于0的
        v2 = models.Host.objects.filter(nid__gt=0).values("nid","host_name","ip","base__caption","port")
        return render(request, "host.html", {"v1": v1,"v2":v2})
    else:
        name = request.POST.get("username",None)
        ip = request.POST.get("ip",None)
        port = request.POST.get("port",None)
        base_id = request.POST.get("group",None)
        print(name,ip,port,base_id)
        models.Host.objects.create(host_name=name,ip=ip,port=port,base_id=base_id)
        return redirect("/host/")


def test_ajax(request):
    res = {"status":True,"error":None,"data":None}
    try:
        name = request.POST.get("name", None)
        ip = request.POST.get("ip", None)
        port = request.POST.get("port", None)
        base_id = request.POST.get("group", None)
        print(name, ip, port, base_id)
        if len(name) >5:
            models.Host.objects.create(host_name=name, ip=ip, port=port, base_id=base_id)
        else:
            res["status"] = False
            res["error"] = "主机名太短"
    except Exception as e:
        res["status"] = False
        res["error"] = "请求错误:%s"%(e)
    return HttpResponse(json.dumps(res))

def app(request):
    if request.method == "GET":
        app_list = models.Application.objects.all()
        host_list = models.Host.objects.all()
        # for row in app_list:
        #     print(row.name,row.r.all())
        return render(request, "app.html", {"app_list": app_list, "host_list": host_list})
    else:
        app_name = request.POST.get("app",None)
        host_list = request.POST.getlist("host_name",None)
        print(app_name, host_list)
        obj = models.Application.objects.create(name=app_name)
        obj.r.add(*host_list)
        return redirect("/app/")

def app_ajax(request):
    res = {"status":True,"error":None,"data":None}
    try:
        app_name = request.POST.get("app",None)
        host_list = request.POST.getlist("host_name",None)
        aid = models.Application.objects.filter(name=app_name).first()
        print(aid.id,app_name,host_list)
        if app_name == "" or len(host_list) == 0:
            res["status"] = False
            res["error"] = "主机名和应用名不能为空"
        else:
            pass
    except Exception as e:
        res["status"] = False
        res["error"] = "错误信息:%s"%e
    return HttpResponse(json.dumps(res))


def tp1(request):
    list = [1,2,3]
    return render(request,"tpl.html",{"list":list})

def tp2(request):
    user = "root"
    list = [1, 2, 3]
    return render(request,"tp2.html",{"user":user,"list":list})

def tp3(request):
    name = "root"
    return render(request,"tp3.html",{"name":name})

def tp4(request):
    from django.utils.safestring import mark_safe
    page = request.GET.get("p",1)
    page = int(page)
    list = []
    for i in range(1,102):
        list.append(i)
    start = (page-1)*10         #每一页第一个数值
    end = page*10               #每一页最好一个数值
    data = list[start:end]      #每页显示几个数值
    all_page = len(list)        #总个数
    count,y = divmod(all_page,10)     #divmod()函数 总个数all_page/每页显示个数 = 需要分多少页 count=页数  y是余数
    if y:                    #判断  总个数/ 每页显示个数  是否能除尽   余数不为0都为True
        count+=1
    pag_list = []
    for row in range(1,count+1):
        tmp = " <a class = 'page' href = '/tp4/?p=%s'>%s</a>"%(row,row)
        pag_list.append(tmp)        #将每个分页a标签添加到pag_list列表中
    page_str = "".join(pag_list)    #将列表转成"<a class = 'page' href = '/tp4/?p=1'>1</a> <a class = 'page' href = '/tp4/?p=2'>2</a>"
    page_str = mark_safe(page_str)  #将字符串通过mark_safe()函数做下安全认证，然后传到前端
    return render(request,"tp4.html",{"list":data,"page_str":page_str})
