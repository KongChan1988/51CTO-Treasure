from django.db import models

# Create your models here.
class Business(models.Model):
    caption = models.CharField(max_length=32)
    code = models.CharField(max_length=32,null=True)  #若新加字段可以在添null=True或default="sa" 参数

class Host(models.Model):
    nid = models.AutoField(primary_key=True)
    host_name = models.CharField(max_length=32,db_index=True)  #db_index创建索引
    ip = models.GenericIPAddressField(protocol="ipv4",db_index=True)  #创建索引并验证IP（Ipv4格式192.168.x.x.）默认both
    port = models.IntegerField()
    base = models.ForeignKey("Business",to_field="id",on_delete=models.CASCADE)

class Application(models.Model):
    name = models.CharField(max_length=32)
    r = models.ManyToManyField("Host")    #此时在数据库会自动生成一张application_r表

# obj = Application.objects.get(id=1)         #获取Application表中id=1的数据
# obj.r.add(1)          #对application_r表中新增  application_id=1  host_id = 1记录
# obj.r.add(2,3)        #对application_r表中新增  application_id=1  host_id = 2和application_id=1  host_id = 3记录
# obj.r.add(*[2,3,4])   #对application_r表中新增  application_id=1  host_id = 2和3和4记录
# obj.r.remove(1)          #对application_r表中删除  application_id=1  host_id = 1记录
# obj.r.remove(2,3)        #对application_r表中删除  application_id=1  host_id = 2和application_id=1  host_id = 3记录
# obj.r.remove(*[2,3,4])   #对application_r表中删除  application_id=1  host_id = 2和3和4记录
# obj.r.clear()       #清除application_r表中application_id=1=1的数据
# obj.r.set([3,5,7])      #此时application_r表中只会存在application_id=1  host_id = 3和5和7记录

class Host_m2m_Appliction(models.Model):
    Hobj = models.ForeignKey("Host",to_field="nid",on_delete=models.CASCADE)
    Aobj = models.ForeignKey("Application",to_field="id",on_delete=models.CASCADE)
#用自定义关系表时添加数据
# Host_m2m_Appliction.objects.create(Hobj_id=1,Aobj_id=1)

