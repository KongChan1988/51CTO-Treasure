from scrapy import cmdline
cmdline.execute("scrapy crawl BaiduSpider".split())
#cmdline.execute("scrapy crawl BingSpider".split())
#cmdline.execute("scrapy crawl SogouSpider".split())
