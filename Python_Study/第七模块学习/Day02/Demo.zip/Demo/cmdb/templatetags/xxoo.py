#-*-coding:utf-8 -*-
# Author: D.Gray
from django import template
from django.utils.safestring import mark_safe
register = template.Library()
@register.simple_tag
def simple(a1,a2):
    return a1+a2

@register.filter
def kyo(a1,a2):
    return a1+str(a2)